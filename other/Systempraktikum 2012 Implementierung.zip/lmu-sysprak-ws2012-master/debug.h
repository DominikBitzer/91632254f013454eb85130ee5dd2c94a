#ifndef DEBUG_H
#define DEBUG_H

#define DEBUG printf

#endif
