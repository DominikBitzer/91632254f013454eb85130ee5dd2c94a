#ifndef AI_H
#define AI_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "globals.h"

char *think(struct field *);

#endif
