#ifndef CONFIG_H
#define CONFIG_H

#include "util.h"
#include "globals.h"

void readConfig(char*);

#endif
