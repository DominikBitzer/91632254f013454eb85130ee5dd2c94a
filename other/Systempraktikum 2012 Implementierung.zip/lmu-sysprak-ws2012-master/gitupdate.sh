#! /bin/sh

ssh neujo@remote.cip.ifi.lmu.de "cd lmu-sysprak-ws2012 && git pull origin master"
