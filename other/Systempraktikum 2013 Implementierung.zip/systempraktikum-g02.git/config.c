#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "config.h"
#include "utils.h"

void configFile (FILE *file, Game *config) {

	char *readFromFile = malloc(256 * sizeof(char));

	while (fgets(readFromFile, 256, file)) {
		if(strncmp(readFromFile, "#", 1) != 0) { // commented lines are not recognized
			if (isMessage(readFromFile, "portnumber")) {
				sscanf(readFromFile, "portnumber = %d\n", &(config->portNumber));
			} else if (isMessage(readFromFile, "hostname")) {
				sscanf(readFromFile, "hostname = %s\n", config->hostName);
			} else if (isMessage(readFromFile, "gamekindname")) {
				sscanf(readFromFile, "gamekindname = %s\n", config->gameKindName);
			} else if (isMessage(readFromFile, "playernumber")) {
				config->hasGivenPlayerNumber = true;
				sscanf(readFromFile, "playernumber = %d\n", &(config->givenPlayerNumber));
			}
		}
	}
	free(readFromFile);
}
