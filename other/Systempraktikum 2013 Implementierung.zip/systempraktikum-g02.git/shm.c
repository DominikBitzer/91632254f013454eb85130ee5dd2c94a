/*	
/	shm.c
*/

#define _XOPEN_SOURCE

#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
 
#include "shm.h"

//delete given shared-memory-segment
void delete(int deleteShmId) {
	if(deleteShmId != 0) {
		int res;
		res = shmctl(deleteShmId, IPC_RMID, NULL);
		if (res == -1) {
			printf("\t[SHM] :: shmctl() :: shmid %d :: command %d\n", deleteShmId, IPC_RMID);
		}
	}
}

int createShm(int dataSize) {
	int shmId;
	shmId  = shmget(IPC_PRIVATE, dataSize, IPC_CREAT | SHM_R | SHM_W);
		if (shmId == -1){
		perror("\t[SHM] :: creating :");
	}
	return shmId;	
}

void *memoryAttach(int shmId) {
	void *temp;
	temp = shmat(shmId, NULL, 0);
	if(temp == (void *) -1) {
		perror("\t[SHM] :: attaching :");
	}
	return temp;
}
