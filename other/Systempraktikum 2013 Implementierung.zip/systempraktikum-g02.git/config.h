#ifndef config_h
#define config_h

#include <stdbool.h>

typedef struct {
	int portNumber;
	char hostName[256];
	char gameKindName[32];
	char clientVersion[32];
	char gameID[12];
	char gameName[256];
	bool hasGivenPlayerNumber;
	int givenPlayerNumber;
	int playerCount;
	int parentPID;
	int childPID;
	int nextStone;
	int fieldSize;
	int shmIdPlayer;
	int shmIdField;
	long moveTime;
	bool move;
} Game;

typedef struct {
	int number;
	char name[256];
	bool ready;
} Player;

void configFile (FILE *file, Game *config);

#endif
