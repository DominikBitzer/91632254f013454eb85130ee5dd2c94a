# Code Style Conventions
## Language
* English
* c99 std

## Blocks 
* no new line for if, for or while, switch-case
* new line to close block
* one tap = 4 blanks

## Functions
* starts with a lower case
* Camelcase 
* no blanks between parameters and brackets

## Structs
* first letter capital

## Comments
* //

## Variables
* starts with a lower case
* Camelcase
* blank before and after operand