/*
/ connector.c
/ network interface for quarto game
/ written on a beautiful day
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <netdb.h>
#include <stdbool.h>

#include "connector.h"
#include "utils.h"
#include "shm.h"
#include "performConnection.h"
#include "config.h"

void *gameData;
Game game;

void connector(int fd[], int shmIdGame) {
	game = *(Game *)gameData;
	
	// create socket
	int mainSocket = socket(AF_INET, SOCK_STREAM, 0); // initializing main socket for server connection
	if (mainSocket <= 0) {
		perror("\t[CLIENT] :: error :: opening socket :");
		exit(EXIT_FAILURE);
	}

	// determine host's IP-adress
	struct hostent *host;
	host = gethostbyname(game.hostName); // reading hostname from game struct (-> from config file)
	if (host == NULL) {
		perror("\t[CLIENT] :: error :: resolving hostname :");
		exit(EXIT_FAILURE);
	}

	struct in_addr **ip_ptr = (struct in_addr **) host->h_addr_list;

	// connect to host
	struct sockaddr_in address;
	memset(&address, 0, sizeof(address));

	address.sin_family = AF_INET;
	address.sin_port = htons(game.portNumber);
	address.sin_addr = **ip_ptr;
	if (connect(mainSocket, (struct sockaddr *) &address, sizeof(address)) < 0) {
		perror("\t[CLIENT] :: error :: establishing connection :");
		exit(EXIT_FAILURE);
	}
	if(performConnection(mainSocket, fd, shmIdGame) == -1) {
		close(mainSocket);
		exit(EXIT_FAILURE);
	}
	
	close(mainSocket);
}
