#ifndef performConnection_h
#define performConnection_h

int performConnection(int mainSocket, int fd[],int shmIdGame);

#endif
