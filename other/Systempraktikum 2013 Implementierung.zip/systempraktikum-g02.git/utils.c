/*
/	utils.c
/	some useful methods
*/

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "utils.h"
#include "config.h"

void printBeginning() {
	printf("\n\n//////////////////////////////////////////\n\033[36m%s\033[0m\n\n//////////////////////////////////////////\n\n\n","\nwe're the\n\n  /        o      /  _/_       o    /          \n /<  _ _  ,  _,  /_  /     _  ,  __/ _  _   (  \n/ |_/ / /_(_(_)_/ /_(__   / (_(_(_/_(/_/ (_/_)_\n             /|                                \n            (/ ");
}

void printEnd() {
	printf("\n\n//////////////////////////////////////////\n\n");
}

void trimString(char *text, int firstNLetter) { // method to cut the first n letters of any string (pointer to string)
	for(int i = 0; i <= strlen(text); i++) {
		if(i > firstNLetter - 1) {
			text[i - firstNLetter] = text[i];
		}
	}
}

void invertString(char *text) { // method to invert string (pointer to string) -> invertString("moep") = "peom"
	char newString[256];
	strcpy(newString, text);
	for(int i = 0; i < strlen(text); i++) {
		newString[i] = text[strlen(text) - i - 1];
	}
	strcpy(text, newString);
}

bool isMessage(char givenRealMessage[], char keyword[]) { // method returns true if given string contains given keyword (bool is easier to handle)
	if (strstr(givenRealMessage, keyword) != NULL) {
		return true;
	} 
	return false;
}

void printNext(Game game) {
	int temp = game.nextStone;
	int *number = malloc(game.fieldSize * sizeof(int));
	printf("\t[CLIENT] :: setting stone :: "); 
	for(int i = 0; i < game.fieldSize; i++) { // print next stone binary
		if ( temp % 2 == 0 ) {
			number[game.fieldSize-i-1] = 0;
		} else {
			number[game.fieldSize-i-1] = 1;
		}
		if (temp == 1) {
			temp = 0;
		}
		temp = temp/2;
	}
	for(int i = 0; i < game.fieldSize; i++) {
		printf("%d", number[i]);
	}
	printf("\n\n");
	free(number);
}

void printField(Game game, int **field) {
	int temp;
	int *number = malloc(game.fieldSize*sizeof(int));
	char fieldLetter = 65; // letters on top of the board
	printf("      ");
	for (int i = 0; i < game.fieldSize; i++) {
		printf("%c", fieldLetter+i);
		for (int j = 0; j <= game.fieldSize; j++) {
			printf(" ");
		}
	}
	printf("\n");
	printf("   +--"); // line above the board
			for (int i = 0; i < game.fieldSize; i++) {
				printf("--");
				for (int j = 0; j < game.fieldSize; j++) {
					printf("-");
				}
			}
			printf("+\n");
	int counter = game.fieldSize;
	for (int i = 0; i < game.fieldSize; i++) { // print field binary
		printf(" %d |  ", counter); // numbers left of the board and left line
		for (int j = 0; j < game.fieldSize; j++) {
			temp = field[i][j];
			if (temp != -1) {
				for(int k = 0; k < game.fieldSize; k++) {
					if ( temp % 2 == 0 ) {
						number[game.fieldSize-k-1] = 0;
					} else {
						number[game.fieldSize-k-1] = 1;
					} 
					if (temp == 1) {
						temp = 0;
					}
					temp = temp/2;
				}
				for(int k = 0; k < game.fieldSize; k++) {
					printf("%d", number[k]);
				}
			} else {
				for(int k = 0; k < game.fieldSize; k++) {
					printf("*");
				}
			}
			printf("  ");
		}
		printf("| %d\n", counter); // numbers right of the board and right line
		counter--;
		if (i < game.fieldSize - 1) {
			printf("   |  "); // right line
			for (int j = 0; j < game.fieldSize; j++) {
				printf("  ");
				for (int k = 0; k < game.fieldSize; k++) {
					printf(" ");
				}
			}
			printf("|\n");
		} else {
			printf("   +--"); // line below the board
			for (int j = 0; j < game.fieldSize; j++) {
				printf("--");
				for (int k = 0; k < game.fieldSize; k++) {
					printf("-");
				}
			}
			printf("+\n");
		}
	}
	fieldLetter = 65; // letters below the board
	printf("      ");
	for (int i = 0; i < game.fieldSize; i++) {
		printf("%c", fieldLetter+i);
		for (int j = 0; j <= game.fieldSize; j++) {
			printf(" ");
		}
	}
	printf("\n\n");
	free(number);
}
