#ifndef connector_h
#define connector_h

void connector(int fd[],int shmIdGame);

#endif
