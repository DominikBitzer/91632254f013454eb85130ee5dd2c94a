/*
/	thinker.c
/	thinks about being the best  
/	parentprocess of connector.c
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>
#include <signal.h>
#include <time.h>

#include "thinker.h"
#include "shm.h"
#include "utils.h"

void *fieldData;
Game game;
int **field;
int *stones;

// initializes field and stones
void initializeField() {
	field = malloc(game.fieldSize * sizeof(int *)); //initialize field as int-matrix
	for (int i = 0; i < game.fieldSize; i++) {
		field [i] = malloc(game.fieldSize * sizeof(int));
	}
	stones = malloc( game.fieldSize * game.fieldSize * sizeof(int)); 
}

// copies field data from shm into field and stones
void readField() {
	for (int i = 0; i < game.fieldSize; i++) {
		for (int j = 0; j < game.fieldSize; j++) {
			field[i][j] = ((int *)fieldData)[i * game.fieldSize + j];
		}
	}
	memset(stones, 0, game.fieldSize * game.fieldSize * sizeof(int)); // initialize stones as int-array with 0 => all stones are available	
	for (int i = 0; i < game.fieldSize; i++) {
		for (int j = 0; j < game.fieldSize; j++) {
			if (field[i][j] != -1) {
				stones[field[i][j]] = 1; // 1 => stone is already in use
			}
		}
	}
	stones[game.nextStone] = 1; // stone client has to place is already in use


}

/*
/ converts data from placeStone() and chooseStone() to string; coord: data from placeStone, stone: data from chooseStone;
/ move: array for the result
*/
void convertMove(int coord[], int stone, char move[]) {
	char y = coord[1]+65; // host counts y coordinate first with capital characters => ASCII
	int x = game.fieldSize-coord[0]; // host counts x coordinate from bottom to top and starts with 1
	if ( stone != -1 ) {
		sprintf(move, "%c%d,%d", y, x, stone);
	} else {
		sprintf(move, "%c%d", y, x);
	}
}

// chooses a random stone for the opponent
int chooseStone() {
	srand(time(NULL));
	int random = rand() % (game.fieldSize * game.fieldSize);
	if (stones[random] == 0) {
		return random;
	}
	for (int i = 1; i < game.fieldSize * game.fieldSize; i++) {
		if ((stones[(random + i) % (game.fieldSize * game.fieldSize)]) == 0) {
			return (random + i) % (game.fieldSize * game.fieldSize);
		}
	}
	return -1;
}

/*
/	places stone randomly, takes next free cell if random cell is not free; 
/	coord: int array (size 2) for coordinates
*/
int placeStone(int coord[]) {
	srand(time(NULL));
	int x = rand() % game.fieldSize;
	srand(time(NULL));
	int y = rand() % game.fieldSize;
	if(field[x][y] == -1) {
		coord[0] = x;
		coord[1] = y;
		return 0;
	} else { 
		for (int i = 0; i < game.fieldSize; i++) {
			for (int j = 0; j < game.fieldSize; j++) {
				if (field[(x + i) % game.fieldSize][(y + j) % game.fieldSize] == -1) {
					coord[0] = (x + i) % game.fieldSize;
					coord[1] = (y + j) % game.fieldSize;
					return 0;
				}
			}
		}
	}
	return -1;
}

//	compares two numbers x and y as binaries; returns int that has a 1 where x and y are the same
int compare(int x, int y) {
	int ret = 0;
	int power = 1;
	for (int i = 0; i < game.fieldSize; i++) {
		ret = ret + power;
		power = power * 2;
	}
	ret = ret & ~(x ^ y);
	return ret;
}

// Sets numbers to compare: compare0: compares all the 0s in all numbers, compare1: compares all the 1s in all number
void initCompares (int *compare0, int *compare1) {
	*compare0 = 0; 
	*compare1 = 1; 
	for (int i = 0; i < game.fieldSize; i++) { 	//initialize compare1 with y ones
		*compare1 = *compare1 * 2;		
	}
	*compare1 = *compare1 - 1;
}

//	compares the numbers in one row in the field and a given int x as binaries; row: number of the row to be compared
int compareRow(int row, int x) {
	int compare0, compare1;
	initCompares(&compare0, &compare1);
	for (int i = 0; i < game.fieldSize; i++) {
		if (field[row][i] != -1) {
			compare0 = compare0 | field[row][i];
			compare1 = compare1 & field[row][i];
		}
	}
	compare0 = compare0 | x;
	compare1 = compare1 & x;
	return compare(compare0, compare1);
}

// like compareRow, but compares columns
int compareColumn(int column, int x) {
	int compare0, compare1;
	initCompares(&compare0, &compare1);
	for (int i = 0; i < game.fieldSize; i++) {
		if (field[i][column] != -1) {
			compare0 = compare0 | field[i][column];
			compare1 = compare1 & field[i][column];
		}
	}
	compare0 = compare0 | x;
	compare1 = compare1 & x;
	return compare(compare0, compare1);
}

// like compareRow, but compares diagonals: 0 for \, 1 for /
int compareDiagonal(int diagonal, int x) {
	int compare0, compare1;
	initCompares(&compare0, &compare1); 
	for (int i = 0; i < game.fieldSize; i++) {
		if (diagonal == 0 && field[i][i] != -1) {
			compare0 = compare0 | field[i][i];
			compare1 = compare1 & field[i][i];
		}
		else if (diagonal == 1 && field[i][game.fieldSize-i-1] != -1) {
			compare0 = compare0 | field[i][game.fieldSize-i-1];
			compare1 = compare1 & field[i][game.fieldSize-i-1];
		}	
	}
	compare0 = compare0 | x;
	compare1 = compare1 & x;
	return compare(compare0, compare1);
}

// counts the stones in a row
int countRow(int row) {
	int count = 0;
	for (int i = 0; i < game.fieldSize; i++) {
		if (field[row][i] != -1) {
			count++;
		}
	}
	return count;
}

// counts the stones in a column
int countColumn(int column) {
	int count = 0;
	for (int i = 0; i < game.fieldSize; i++) {
		if (field[i][column] != -1) {
			count++;
		}
	}
	return count;
}

// counts the stones in a diagonal => 0 for \, 1 for / 
int countDiagonal(int diagonal) {
	int count = 0;
	for (int i = 0; i < game.fieldSize; i++) {
		if (diagonal == 0 && field[i][i] != -1) {
			count++;
		} else if (diagonal == 1 && field[i][game.fieldSize-i-1] != -1) {
			count++;
		}
	}
	return count;
}

// checks if client can in next move; coord[]: int array (size 2) for result, x: stone to be compared
int canIWin(int coord[], int x) {
	for(int i = 0; i < game.fieldSize; i++) {
		//searches row with 3 placed stones and checks if nextStone has a matching attribute
		if(compareRow(i, x) > 0 && countRow(i) == game.fieldSize - 1) {	
			for(int j = 0; j < game.fieldSize; j++) {
				if(field[i][j] == -1) {	//sets coordinates
					coord[0] = i;
					coord[1] = j;
					return 0;
				}
			}
		}
		//does the same as above, but with columns
		if(compareColumn(i, x) > 0 && countColumn(i) == game.fieldSize - 1) {
			for(int j = 0; j < game.fieldSize; j++) {
				if(field[j][i] == -1) {
					coord[0] = j;
					coord[1] = i;
					return 0;
				}
			}
		}
	}
	//does the same as above but with diagonal 0 (is \ one)
	if(compareDiagonal(0, x) > 0 && countDiagonal(0) == game.fieldSize -1) {
		for(int j = 0; j < game.fieldSize; j++) {
			if(field[j][j] == -1) {
				coord[0] = j;
				coord[1] = j;
				return 0;
			}
		}
	}
	//does the same as above but with diagonal 1 (is / one)
	if(compareDiagonal(1, x) > 0 && countDiagonal(1) == game.fieldSize -1) {
		for(int j = 0; j < game.fieldSize; j++) {
			if(field[j][game.fieldSize-j-1] == -1) {
				coord[0] = j;
				coord[1] = game.fieldSize-j-1;
				return 0;
			}
		}
	}
	return -1;
}

int canIWinNextTime (int coord[]) {
	int next = -1;
	for (int i = 0; i < game.fieldSize; i++) {
		//In one row there are two placed stones, and them and game.nextStone has one matching attribute
		if (countRow(i) == game.fieldSize - 2 && compareRow(i, game.nextStone) > 0) {
			for (int j = 0; j < game.fieldSize * game.fieldSize; j++) {
				//if there's a stone that doesn't have a matching attribute as the ones in the row
				if (stones[j] == 0 && compareRow(i, stones[j]) == 0) {
					next = j;		//opponent gets this stone
					//I place game.nextStone here, hoping I get a matching stone next time
					for (int k = 0; k < game.fieldSize; k++) {
						if (field[i][k] == -1) {
							coord[0] = i;
							coord[1] = k;
				 		}
					}
					return next;
				}
			}
		}
		//does the same as above but with columns
		if (compareColumn(i, game.nextStone) > 0 && countColumn(i) == game.fieldSize - 2) {
			for (int j = 0; j < game.fieldSize * game.fieldSize; j++) {
				if (stones[j] == 0 && compareColumn(i, stones[j]) == 0) {
					next = j;
					for (int k = 0; k < game.fieldSize; k++) {
						if (field[k][i] == -1) {
							coord[0] = k;
							coord[1] = i;
						}
					}
					return next;
				}
			}
		}
	}
	if(compareDiagonal(0, game.nextStone) > 0 && countDiagonal(0) == game.fieldSize - 2) {
		for (int j = 0; j < game.fieldSize * game.fieldSize; j++) {
			if(stones[j] == 0 && compareDiagonal(0, stones[j]) == 0) {
				next = j;
				for (int i = 0; i < game.fieldSize; i++) {
					if (field[i][i] == -1) {
						coord[0] = i;
						coord[1] = i;
					}
				}
				return next;
			}
		}
	}
	if(compareDiagonal(1, game.nextStone) > 0 && countDiagonal(1) == game.fieldSize - 2) {
		for (int j = 0; j < game.fieldSize * game.fieldSize; j++) {
			if(stones[j] == 0 && compareDiagonal(0, stones[j]) == 0) {
				next = j;
				for (int i = 0; i < game.fieldSize; i++) {
					if (field[i][game.fieldSize-i-1] == -1) {
						coord[0] = i;
						coord[1] = game.fieldSize-i-1;
					}
				}
				return next;
			}
		}
	}
	return -1;
}

/*
/ Checks if opponent can win in his/her next move.
/ coord: Coordinates where the free place is with which you can win,
*/
int canOpponentWin(int coord[]) {
	int next = -1;
	int nextTime = -1;
	for( int i = 0; i < game.fieldSize * game.fieldSize ; i++ ) {
		if(stones[i] == 0 && canIWin(coord, i) == -1) { // is there a stone I can choose with which the opponent cannot win?	
			next = i;
		} else {
			stones[i] = 1;
		}
	}
	if (next > -1) {
		if ((nextTime = canIWinNextTime(coord)) > -1 ) { // can I win next time with one of those stones?
			return nextTime;
		} else {
			placeStone(coord);
			return next;
		}		
	}
	// If opponent can win with every stone left: try to block them
	readField();
	int compare0; 
	int compare1;   
	for (int i = 0; i < game.fieldSize; i++) {		//checks every row and column
		if (countRow(i) == game.fieldSize - 1) {	//are there (in our case) 3 stones in a row
			//Checks if the stones in the row have one matching attribute
			initCompares(&compare0, &compare1);
			for (int j = 0; j < game.fieldSize; j++) {
				if (field[i][j] != -1) {
					compare0 = field[i][j] | compare0;
					compare1 = field[i][j] & compare1;
				}
			} 
			if (compare(compare0, compare1) > 0) {		//if they have a matching attribute, I block the row	
				for (int j = 0; j < game.fieldSize; j++) {
					if (field[i][j] == -1) {
						coord[0] = i;
						coord[1] = j;
						next = chooseStone(); 
						return next;
					}
				}
			}
		}
		//does the same as above, but with columns
		if(countColumn(i) == game.fieldSize - 1) {
			initCompares(&compare0, &compare1);
			for (int j = 0; j < game.fieldSize; j++) {
				if (field[j][i] != -1) {
					compare1 = field[j][i] & compare1;
					compare0 = field[j][i] | compare0;
				}
			} 
			for (int j = 0; j < game.fieldSize; j++) {
				if (field[j][i] == -1) {
					coord[0] = j;
					coord[1] = i;
					next = chooseStone();
					return next;
				}
			}
		}
	}
	if(countDiagonal(0) == game.fieldSize -1) {
		initCompares(&compare0, &compare1);
		for (int i = 0; i < game.fieldSize; i++) {
			if (field[i][i] != -1) {
				compare1 = field[i][i] & compare1;
				compare0 = field[i][i] | compare0;
			}
		}
		for (int i = 0; i < game.fieldSize; i++) {
			if (field[i][i] == -1) {
				coord[0] = i;
				coord[1] = i;
				next = chooseStone();
				return next;
			}
		}
	}
	if(countDiagonal(1) == game.fieldSize -1) {
		initCompares(&compare0, &compare1);
		for (int i = 0; i < game.fieldSize; i++) {
			if (field[i][i] != -1) {
				compare1 = field[i][game.fieldSize-i-1] & compare1;
				compare0 = field[i][game.fieldSize-i-1] | compare0;
			}
		} 
		if (compare(compare0, compare1) > 0) {
			for (int i = 0; i < game.fieldSize; i++) {
				if (field[i][game.fieldSize-i-1] == -1) {
					coord[0] = i;
					coord[1] = game.fieldSize-i-1;
					next = chooseStone();
					return next;
				}
			}
		}
	}
	return -1;
}


// next move all in one; takes a char array with 6 characters for the result
void moveComplete (char move[]) {
	int coord[2];
	int next;
	//checks if game can be won
	if (canIWin(coord, game.nextStone) == 0) {
		next = chooseStone();	//if so chooses random stone for opponent, because it doesn't matter anyway
		convertMove(coord, next, move);
	} else if ((next = canOpponentWin(coord)) > -1) { //checks if opponent can win in his/her next move
		convertMove(coord, next, move);
	} else {
		placeStone(coord); //if nothing of the things above match, choose random opponent's stone and random place for nextStone
		next = chooseStone();
		convertMove(coord, next, move);
	}
}

void thinker(int fd[], void *gameData) {
	game = *(Game *) gameData;
	fieldData = memoryAttach(game.shmIdField);
	if ( game.move ) { // move is requested
		initializeField();
		readField();
		char move[10];
		moveComplete(move);
		game.move = false; // reset move
		*(Game *) gameData = game;
		int res;
		res = write(fd[1], move, strlen(move) + 1); // send move to connector over pipe
		if(res == -1){
			perror("\t[IPC] :: pipe :: write :");
			raise(SIGINT);
		}
		for (int i = 0; i < game.fieldSize; i++) {
			free(field [i]);
		}
		free(field);
		free(stones);
	}
}
