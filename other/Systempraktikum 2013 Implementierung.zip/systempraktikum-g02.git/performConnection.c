/*
/ 	performConnection.c
/ 	implements protocol for host communication
*/

#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <netdb.h>
#include <stdbool.h>
#include <signal.h>
#include <sys/select.h>

#include "utils.h"
#include "shm.h"
#include "thinker.h"
#include "performConnection.h"

Game game;
void *gameData;

/*
/	converts the game field from string list to int matrix (saved in field)
/	parameter fieldstring: game field as string list
*/
void convertField(char **fieldString, int **field) {
	
	char *line;
	char digits[10];

	for (int i = 0; i < game.fieldSize; i++) {

		line 		= fieldString[i];
		int count 	= 0; // counts digits
		int column 	= 0;

		for (int j = 0; j <= strlen(line); j++) {
			if (line[j] != ' ' && line[j] != '\0') {
				digits[count] = line[j];
				count++;
			} else {
				digits[count] = '\0';
				if (2 + count < j) { // omit + and first number
					if (strcmp(digits, "*") != 0) {
						sscanf(digits, "%d", &(field[i][column]));
					} else {
						field[i][column] = -1;
					}
					column++;
				}
				count = 0;
			}
		}
	}
}

void cleanUp(char **currentField, int **field, void *playerData, void *playerDataFree, char *messageIN, Player *playerFree) { // free allocated memory in case of error / end of socket connection
	for(int i = 0; i < game.fieldSize; i++) {
		free(currentField[i]);
	}

	for(int i = 0; i < game.fieldSize; i++) {
		free(field[i]);
	}

	free(currentField);
	free(field);
	free(playerDataFree);
	free(playerFree);
	free(messageIN);
	printEnd();
}

void sendMessage(int mainSocket, char givenMessage[], char appendix[]) {
	char messageOUT[256];
	sprintf(messageOUT, "%s%s\n", givenMessage, appendix); // add appendix to message
	send(mainSocket, messageOUT, strlen(messageOUT), 0); // and send it
}

int performConnection(int mainSocket, int fd[], int shmIdGame) {

	int **field;
	char **currentField;
	int maxLength 			= 256; // hope that's enough

	int shmIdField;
	void *fieldData;

	Player *player;
	int shmIdPlayer;
	void *playerData;

	ssize_t size;
	char null[256];	

	game 					= *(Game *) gameData;
	playerData 				= malloc(maxLength * sizeof(Player));
	player 					= malloc(maxLength * sizeof(Player));

	// need those to free playerData memory later (playerData and player showing to SHM adress -> cannot free)
	void *playerDataFree 	= playerData;
	Player *playerFree 		= player;

	char *messageIN 		= malloc(maxLength * sizeof(char));
	
	int afterMove 			= 0; // needed to count new lines after "MOVE" from server, no keywords in some of the following messages
	int newLineCount 		= 0; // counts new lines from server in general
	int playersReadyCount 	= 0; // counts the amount of players who are ready -> check whether we're still waiting for new clients to connect
	int initialCount 		= 0; // counts whether this is the first time we're receiving this message (*initial* -> field -> play -> new field -> new play -> game over)

	bool isQuarto			= false;
	bool thinking 			= false;
	bool allPlayersReady 	= true; // is set false with the first player who is not ready -> remains true if all players are ready
	bool receivingPlayers 	= false;
	bool isFirst 			= true; // is set false with the last command in the first (initial) server messages (field)
	bool gameOver 			= false;

	while((size = recv(mainSocket, messageIN, 255, 0)) > 0) {
		messageIN[size] 	= '\0';
		char *newLinePtr 	= strtok(messageIN, "\n");

		int totalCount 		= -1; // has to be -1 to avoid creating player SHM at the very beginning
		int thisPlayer 		= 1;

		while(newLinePtr != NULL) { // splits server messages into new lines -> easier to handle
			if (isMessage(newLinePtr, "accepting connections")) {
				sendMessage(mainSocket, "VERSION ", game.clientVersion);
			} else if (isMessage(newLinePtr, "send Game-ID to join"))  {
				sendMessage(mainSocket, "ID ", game.gameID);
			} else if (isMessage(newLinePtr, "PLAYING")) {
				if (isMessage(newLinePtr, "Quarto")) {
					printf("\t[GAME] :: Quarto\n");
					isQuarto = true;
				} else {
					printf("\t[GAME] :: NOT Quarto - Exiting\n");
					cleanUp(currentField, field, playerData, playerDataFree, messageIN, playerFree);
					return -1; // TODO: check whether we need to free some memory if this is not Quarto
				}
			} else if (isMessage(newLinePtr, "exiting") ||strncmp(newLinePtr, "-", 1) == 0) {
				if (isMessage(newLinePtr, "No free computer player found for that game")) {
					printf("\t[SERVER] :: error :: Seems like they already have somebody to play with.\n");
				} else {
					printf("\n\t[SERVER] :: error :: %s\n\t[CLIENT] :: error :: Server is exiting, we're exiting, too.\n", newLinePtr);
				}

				cleanUp(currentField, field, playerData, playerDataFree, messageIN, playerFree);

				return -1;
			}

			if (newLineCount == 3 && isQuarto) {
				
				char *tmp = malloc(maxLength * sizeof(char));
				strcpy(tmp, newLinePtr);
			 	trimString(tmp, 2);

				strcpy(game.gameName, tmp);

				if (game.hasGivenPlayerNumber) {
					char *tmp = malloc(3 * sizeof(int));
					sprintf(tmp, " %d", game.givenPlayerNumber);
					sendMessage(mainSocket, "PLAYER", tmp);
					free(tmp);
				} else {
					sendMessage(mainSocket, "PLAYER ", ""); // no player number given
				}

				free(tmp);
			}

			if (isMessage(newLinePtr, "YOU")) {

				char *tmp 			= malloc(maxLength * sizeof(char));
				strcpy(tmp, newLinePtr);
				player[0].ready 	= true; // i am always ready
				player[0].number 	= atoi(&(newLinePtr[6]));
				trimString(tmp, 8);

				sprintf(tmp, "%s%s", tmp, "\0");
				strcpy(player[0].name, tmp);

				printf("\t[GAME] :: name :: %s\n", game.gameName);

				printf("\t[PLAYER] :: receiving player information\n\n");

				printf("\t\t[ME] :: name :: %s\n\t\t[ME] :: number :: %d\n\t\t[ME] :: \033[32mready\033[0m (sure I am)\n\n", player[0].name, player[0].number + 1);
				free(tmp);
			}

			if (isMessage(newLinePtr, "TOTAL")) {
				sscanf(newLinePtr, "%s %s %d", null, null, &(game.playerCount)); // null = /dev/zero

				receivingPlayers = true;
				totalCount = 1;
			} else if (totalCount > 0 && totalCount <= game.playerCount - 1 && receivingPlayers) {
				
				char *tmp 					= malloc(maxLength * sizeof(char));
				strcpy(tmp, newLinePtr);
				int intReady 				= 0;
				player[thisPlayer].number 	= atoi(&(newLinePtr[2]));
				
				trimString(tmp, 4);
				invertString(tmp);
				intReady 					= atoi(&(tmp[0]));
				trimString(tmp, 2);
				invertString(tmp);
				strcpy(player[thisPlayer].name, tmp);

				player[thisPlayer].ready = (intReady == 1) ? true : false; // set true / false if player is ready or not

				printf("\t\t[%dND PLAYER] :: name :: %s\n\t\t[%dND PLAYER] :: number :: %d\n", thisPlayer + 1, player[thisPlayer].name, thisPlayer + 1, player[thisPlayer].number);

				if (player[thisPlayer].ready) {
					printf("\t\t[%dND PLAYER] :: \033[32mready\033[0m\n\n",thisPlayer + 1);
				} else {
					printf("\t\t[%dND PLAYER] :: \033[31mNOT ready\033[0m\n\n",thisPlayer + 1);
					allPlayersReady = false;
				}
				
				if (totalCount == game.playerCount - 1) {
					receivingPlayers = false;
				}

				thisPlayer++;
				totalCount++; // to jump into inserting new player OR creating player SHM

				free(tmp);

			} else if ((totalCount == game.playerCount) && !receivingPlayers) {
				
				shmIdPlayer 		= createShm(game.playerCount * sizeof(Player)); // create SHM with size of amount of players
				playerData 			= memoryAttach(shmIdPlayer);
				game.shmIdPlayer	= shmIdPlayer;
				*(Game *) gameData 	= game;
				
				for(int i = 0; i < game.playerCount; i++) {
					((Player *)playerData)[i] = player[i]; // write player into player SHM
				}
				printf("\t[CLIENT] :: Got all players. Wrote them into SHM. Ready to start.");
				printEnd();
				totalCount = -1; // no more player SHM is needed -> != playerCount
			}

			if (isMessage(newLinePtr, "WAIT")) {
				sendMessage(mainSocket, "OKWAIT", ""); // send okwait if we need to wait
				if (!allPlayersReady) {
					printf("\t[CLIENT] :: Waiting for all players to get ready.\n");
				} else {
					if (playersReadyCount == 0) {
						printf("\t[CLIENT] :: Waiting for other player to set stone.\n");
						playersReadyCount++;
					}
				}
			} 

			if ((isMessage(newLinePtr, "MOVE") && !isMessage(newLinePtr, "MOVEOK")) || (gameOver && afterMove == game.fieldSize + 4)) {

				afterMove 		= (gameOver) ? 1 : 0; // skip one line after "MOVE" when game is already over (just needed to print final field)

				if (!gameOver) {
					sscanf(newLinePtr, "%s %s %ld", null, null, &(game.moveTime));
				
					if (initialCount == 0) { 
						printf("\t[SERVER] :: movement :: %ldms\n", game.moveTime); 
					}
				}
				
				afterMove++;
			} else if (afterMove == 1) {
				sscanf(newLinePtr, "%s %s %d", null, null, &(game.nextStone));
				if (initialCount == 0) { // only print this with the firyst messages
					printf("\t[SERVER] :: next stone :: %d\n", game.nextStone);
				}
				afterMove++;
			} else if (afterMove == 2) {
				if (initialCount == 0) { 
					sscanf(newLinePtr, "%s %s %d,%d", null, null, &(game.fieldSize), &(game.fieldSize));
					printf("\t[SERVER] :: fieldsize :: %dx%d.\n", game.fieldSize, game.fieldSize);
					
					currentField 	= malloc(game.fieldSize * sizeof(char*));
					initialCount++;
				} else if (initialCount == 1) {
					// received fieldsize for the second time -> all players must be ready
					allPlayersReady = true;
					initialCount++;
				}

				afterMove++;
			} else if (afterMove > 2 && afterMove < 3 + game.fieldSize) {
				if (isFirst) {
					currentField[afterMove - 3] = malloc(maxLength * sizeof(char));
				}

				strcpy(currentField[afterMove - 3], newLinePtr);
				if (afterMove == game.fieldSize + 2) { 
					
					if (isFirst) { // only create fieldshm with the first time I receive data, create here because now I received fieldSize
						shmIdField 		= createShm(game.fieldSize * game.fieldSize * sizeof(int));
						game.shmIdField = shmIdField;
						fieldData 		= memoryAttach(shmIdField);
						field 			= malloc(game.fieldSize * sizeof(int *));


						for (int i = 0; i < game.fieldSize; i++) {
							field[i] 	= malloc(game.fieldSize * sizeof(int));
						}

						isFirst 		= false;
					}

					convertField(currentField, field); 
					if (!gameOver) {
						printNext(game);
					}
					printField(game, field);

					for (int i = 0; i < game.fieldSize; i++) {
						for (int j = 0; j < game.fieldSize; j++) {
							((int *)fieldData)[i * game.fieldSize + j] = field[i][j]; // write field into field SHM
						}
					}

					*(Game *) gameData 	= game;
				}
				afterMove++;
			} else if (!gameOver && (afterMove == game.fieldSize + 3)) {
				sendMessage(mainSocket, "THINKING", "");
				thinking = true;
				afterMove++;
			} else if (thinking && afterMove == game.fieldSize + 4) {
				
				char moveArray[10];
				game.move 			= true; // step 1 to acticate thinker
				*(Game *) gameData 	= game;
				thinking 			= false;
				playersReadyCount	= 0;

				kill(game.parentPID, SIGUSR1);

				struct timeval waitTime;
				waitTime.tv_usec 	= 0;
				waitTime.tv_sec 	= game.moveTime / 1000; // movetime in seconds -> timeout for select

				fd_set readfds;
				FD_ZERO(&readfds);
				FD_SET(fd[0], &readfds); // add pipe fd to select
				FD_SET(mainSocket, &readfds); // add mainsocket fd to select

				int retVal 		= select(mainSocket + 1, &readfds, NULL, NULL, &waitTime);

				if (retVal == -1) {
					perror("\t[IPC] :: select :");
				} else if (retVal == 0) {
					printf("\t[CLIENT] :: thinker was too slow :: exiting\n");
					cleanUp(currentField, field, playerData, playerDataFree, messageIN, playerFree);
					return -1;
				} else {
					if (FD_ISSET(fd[0], &readfds)) {
						int res;
						res = read(fd[0], moveArray, 10 * sizeof(char));
						if (res == -1) {
							perror("\t[IPC] :: pipe :: read :");
							printf("\t[CLIENT] :: pipe error :: exiting\n");
							cleanUp(currentField, field, playerData, playerDataFree, messageIN, playerFree);
							return -1;
						}
						sendMessage(mainSocket, "PLAY ", moveArray);
					}
					if (FD_ISSET(mainSocket, &readfds)) {
						if ((size = recv(mainSocket, messageIN, 255, 0)) > 0) {
							messageIN[size] 	= '\0';
							printf("\t[SERVER] :: error :: %s\n\t[CLIENT] :: received unexpected server message :: exiting", messageIN);
							cleanUp(currentField, field, playerData, playerDataFree, messageIN, playerFree);
							return -1;
						}
					}
				}	
			}

			if (isMessage(newLinePtr, "GAMEOVER")) {

				gameOver = true;

				printEnd();

				if (strlen(newLinePtr) < 12) { // receiving no winner name -> no winner no looser
					printf("[GAME] :: Game is over. We have no winner and no looser. Cheers!\n");
				} else {

					char *tmp1 = malloc(maxLength * sizeof(char));
					char *tmp2 = malloc(maxLength * sizeof(char));

					strcpy(tmp1, newLinePtr);
					trimString(tmp1, 13);
					strcpy(tmp2, newLinePtr);
					trimString(tmp2, 11);
					invertString(tmp2);
					trimString(tmp2, strlen(tmp1));

					int winnerPlayerNumber = atoi(tmp2) - 1; // -1 due to bug in server
					char *winnerPlayerName = tmp1;

					if (isMessage(winnerPlayerName, player[0].name)) {
						printf("\n\t[GAME] :: We won this game.\n");
					} else {
						printf("\n\t[GAME] :: Game is over. We lost. Winner is player number %d. Cheers, %s.\n\n\t[Gee, Brain, what do you want to do tonight?]\n\t[The same thing we do every night, Pinky: try to take over the world!]\n", winnerPlayerNumber + 1, winnerPlayerName);
					}

					printf("\n\t[SERVER] :: final field below\n\n\n");
					free(tmp1);
					free(tmp2);
				}
			}

			newLineCount++;
			newLinePtr = strtok(NULL, "\n");
		}
	}
	
	cleanUp(currentField, field, playerData, playerDataFree, messageIN, playerFree);
	return 0;
}
