#ifndef thinker_h
#define thinker_h

void thinker(int fd[], void *gameData);

#endif
