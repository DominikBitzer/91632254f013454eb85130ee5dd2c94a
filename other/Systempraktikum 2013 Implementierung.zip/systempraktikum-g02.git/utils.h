#ifndef utils_h
#define utils_h

#include "config.h"

void printBeginning();
void printEnd();
void trimString(char *text, int firstNLetter);
void invertString(char *text);
bool isMessage(char givenRealMessage[], char keyword[]);
void printNext(Game game);
void printField(Game game, int **field);

#endif
