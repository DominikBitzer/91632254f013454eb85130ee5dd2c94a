/*
/	main.c
/	implements main method for quarto ai
*/

#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>
#include <signal.h>

#include "config.h"
#include "shm.h"
#include "connector.h"
#include "thinker.h"
#include "utils.h"

int fd[2];
int shmIdGame;
Game game;
void *gameData;


void deleteShm() {
	game = *(Game *)gameData;
	delete(game.shmIdField);
	delete(game.shmIdPlayer);
	delete(shmIdGame);
}

//handles SIGUSR1 and SIGTERM
void handle(int sig) {
	if( sig == SIGUSR1 ) {
		thinker(fd, gameData);
	} else if( sig == SIGINT ) {
		deleteShm();
		kill(game.childPID, SIGTERM);
		if( wait(NULL) < 0 ) {
			perror("\t[IPC] :: wait :");
		}
		exit(EXIT_FAILURE);
	}
}

int main(int argc, char *argv[]) {
	printBeginning();

	FILE *file;

	if (argc > 3 || argc == 1) {
		printf("\t[CLIENT] :: usage :: client <Game-ID> <configFile [optional]>\n\t[CLIENT] :: exiting\n");
		printEnd();
		exit(EXIT_FAILURE);
	} else if (argc == 2) {
		file = fopen("client.conf", "r");
	} else if (argc == 3) {
		file = fopen(argv[3], "r");
	} 

	if (strlen(argv[1]) != 11) {
		printf("\t[CLIENT] :: error :: Game-ID must have 11 digits.\n\t[CLIENT] :: exiting\n");
		printEnd();
		exit(EXIT_FAILURE);
	} 

	shmIdGame = createShm(sizeof(Game));
	gameData = memoryAttach(shmIdGame);

	game = *(Game *) gameData;
	game.parentPID = getpid();
	
	configFile(file, &game);
	fclose(file);
	strncpy(game.gameID, argv[1], 12);
	strncpy(game.clientVersion, "1.0", 32);

	*(Game *) gameData = game;
		
		
	// create pipe
	int retcode = pipe(fd);
	if(retcode < 0){
		perror("\t[IPC] :: creating pipe :");
		deleteShm();
		exit(EXIT_FAILURE);
	}

	// create child process
	pid_t pid = fork();
	switch(pid) {
		case -1:
			perror("\t[IPC] :: fork :");
			deleteShm();
			exit(EXIT_FAILURE);
			break;
				
		case 0: // child process
			close(fd[1]); // read only

			game.childPID 		= getpid();
			*(Game *) gameData 	= game;

			connector(fd, shmIdGame);
			break;
				
		default: // parent process
			close(fd[0]); // write only
			
			//signal handler
			struct sigaction action;
			sigemptyset(&action.sa_mask);
			action.sa_handler = handle;
			action.sa_flags = SA_RESTART;
			if (sigaction(SIGUSR1, &action, NULL) < 0 || sigaction(SIGINT, &action, NULL) < 0) {
				perror("\t[IPC] :: sigaction :");
				deleteShm();
				kill(game.childPID, SIGTERM);
				exit(EXIT_FAILURE);
			}

			// wait for termination of child process
			if(wait(NULL) < 0){
				perror("\t[IPC] :: wait :");
				deleteShm();
				kill(game.childPID, SIGTERM);
				exit(EXIT_FAILURE);
			}
			deleteShm();	
			break;
	}	
	return EXIT_SUCCESS;	
}
