#ifndef shm_h
#define smh_h

void delete(int shmid);
void *memoryAttach(int shmId);
int createShm(int datasize);

#endif
